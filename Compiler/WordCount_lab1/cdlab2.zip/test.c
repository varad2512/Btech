#include<stdio.h>

int main()
{
cout<<"hello";

return 0;
}
